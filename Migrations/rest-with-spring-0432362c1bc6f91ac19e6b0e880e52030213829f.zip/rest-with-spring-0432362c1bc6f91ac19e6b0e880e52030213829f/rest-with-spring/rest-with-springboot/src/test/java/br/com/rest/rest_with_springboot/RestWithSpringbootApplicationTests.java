package br.com.rest.rest_with_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
